function setBgGreen() {
    document.body.style.backgroundColor = 'green';
}
​
function setBgRed() {
    document.body.style.backgroundColor = 'red';
}

header, .row {
    display: flex;  
  }
  
  .col {
    flex: 1;        
  }
